<?php
namespace ApSemplice\Admin;

use ApSemplice\CardLayout;
use ApSemplice\Frontend\Assets;
use ApSemplice\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Aspetto: logo e colori principale e secondario. Di default si prendono dal sito (Elementor o tema); ognuno si può personalizzare.
 * Valgono per tessera, pulsanti e pagine di verifica dei soci. Solo amministratori.
 */
final class AppearancePage {

	/** Scelta della tessera: standard (bianca) oppure su un'immagine propria con i dati trascinabili. */
	private static function card_section( array $s ): void {
		$bg     = CardLayout::bg_url();
		$layout = CardLayout::layout();
		$sample = CardLayout::samples();
		$mode   = CardLayout::MODE_IMAGE === (string) $s['card_mode'] ? CardLayout::MODE_IMAGE : CardLayout::MODE_STANDARD;
		echo '<h2>Tessera</h2><input type="hidden" name="card_present" value="1">';
		echo '<p><label><input type="radio" name="card_mode" value="standard"' . checked( CardLayout::MODE_STANDARD === $mode, true, false ) . '> <strong>Tessera standard</strong>: bianca, con il logo e i testi nel colore principale.</label><br>'
			. '<label><input type="radio" name="card_mode" value="image"' . checked( CardLayout::MODE_IMAGE === $mode, true, false ) . '> <strong>Tessera su un\'immagine mia</strong>: carichi il disegno della tessera e trascini sopra nome, numero, scadenza e QR.</label></p>';
		echo '<div id="apse-card-image"><input type="hidden" name="card_bg_id" id="apse-card-bg-id" value="' . (int) $s['card_bg_id'] . '">'
			. '<p><button type="button" class="button" id="apse-cardbg-pick">Scegli l\'immagine della tessera</button> <span class="description">Meglio un\'immagine orizzontale, con uno spazio libero dove vanno i dati (ad esempio 1011 × 638 pixel). Trascina le scritte dove vuoi, poi regola dimensione e colore.</span></p>';
		echo '<div id="apse-cardedit" style="position:relative;max-width:640px;container-type:inline-size;border:1px solid #c3c4c7;background:#f0f0f1;aspect-ratio:1011/638">';
		echo '<img id="apse-cardedit-img" src="' . esc_url( $bg ) . '" alt="" style="display:' . ( '' !== $bg ? 'block' : 'none' ) . ';width:100%;height:auto">';
		echo '<div id="apse-cardedit-empty" class="description" style="position:absolute;top:8px;left:12px;' . ( '' !== $bg ? 'display:none' : '' ) . '">Nessuna immagine scelta.</div>';
		foreach ( CardLayout::FIELDS as $k => $label ) {
			$f = $layout[ $k ];
			if ( 'qr' === $k ) {
				echo '<span class="apse-chip" data-f="qr" style="position:absolute;left:' . (float) $f['x'] . '%;top:' . (float) $f['y'] . '%;width:' . (float) $f['size'] . '%;aspect-ratio:1;background:#fff;border:1px dashed #333;cursor:move;display:flex;align-items:center;justify-content:center;font-size:3cqw;color:#333">QR</span>';
			} else {
				echo '<span class="apse-chip" data-f="' . esc_attr( $k ) . '" style="position:absolute;left:' . (float) $f['x'] . '%;top:' . (float) $f['y'] . '%;font-size:' . (float) $f['size'] . 'cqw;color:' . esc_attr( $f['color'] ) . ';cursor:move;white-space:nowrap;font-weight:600;outline:1px dashed rgba(0,0,0,.45)">' . esc_html( $sample[ $k ] ) . '</span>';
			}
		}
		echo '</div>';
		echo '<table class="widefat striped" style="max-width:640px;margin-top:10px"><thead><tr><th>Dato</th><th>Mostra</th><th>Dimensione</th><th>Colore</th><th>Posizione (%)</th></tr></thead><tbody>';
		foreach ( CardLayout::FIELDS as $k => $label ) {
			$f = $layout[ $k ];
			echo '<tr><td>' . esc_html( $label ) . '</td>'
				. '<td><input type="hidden" name="layout[' . esc_attr( $k ) . '][show]" value="0"><input type="checkbox" name="layout[' . esc_attr( $k ) . '][show]" value="1"' . checked( ! empty( $f['show'] ), true, false ) . '></td>'
				. '<td><input type="number" step="0.5" min="1" max="40" name="layout[' . esc_attr( $k ) . '][size]" value="' . (float) $f['size'] . '" style="width:70px"></td>'
				. '<td>' . ( 'qr' === $k ? '—' : '<input type="color" name="layout[' . esc_attr( $k ) . '][color]" value="' . esc_attr( $f['color'] ) . '">' ) . '</td>'
				. '<td>x <input type="number" step="0.5" min="0" max="100" name="layout[' . esc_attr( $k ) . '][x]" value="' . (float) $f['x'] . '" style="width:70px"> y <input type="number" step="0.5" min="0" max="100" name="layout[' . esc_attr( $k ) . '][y]" value="' . (float) $f['y'] . '" style="width:70px"></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</tbody></table><p class="description">Per il QR la dimensione è la larghezza in percentuale della tessera; per i testi è la grandezza delle lettere (percentuale della larghezza). Con l\'immagine scelta la tessera si stampa uguale a come la vedi qui.</p></div>';
	}

	public static function render(): void {
		wp_enqueue_media();
		$s       = Settings::all();
		$logo    = Assets::logo_url();
		$own_id  = (int) $s['logo_id'];
		$site_p  = Assets::theme_accent();
		$site_s  = Assets::theme_color( 'secondary' );
		$p_own   = '' !== (string) $s['accent_color'];
		$s_own   = '' !== (string) $s['secondary_color'];
		Ui::header( 'Impostazioni: aspetto' );
		echo '<p class="description">Logo e colori della tessera, dei pulsanti e delle pagine dei soci. Di default si prendono dal sito (Elementor o tema); se vuoi, scegli i tuoi.</p>';
		Ui::form_open( 'apse_save_look', Ui::url( 'apse-look' ) );
		echo '<table class="form-table"><tbody>';

		echo '<tr><th>Logo</th><td><div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">'
			. '<div id="apse-logo-preview" style="min-width:120px;min-height:56px;padding:8px;border:1px dashed #c3c4c7;background:#fff">'
			. ( '' !== $logo ? '<img src="' . esc_url( $logo ) . '" alt="" style="max-height:56px;max-width:220px;display:block">' : '<span class="description">Nessun logo trovato</span>' ) . '</div>'
			. '<input type="hidden" name="logo_id" id="apse-logo-id" value="' . (int) $own_id . '">'
			. '<button type="button" class="button" id="apse-logo-pick">Scegli dalla libreria</button> '
			. '<button type="button" class="button" id="apse-logo-clear"' . ( $own_id ? '' : ' style="display:none"' ) . '>Usa il logo del sito</button></div>'
			. '<p class="description">' . ( $own_id ? 'Stai usando il logo scelto qui.' : 'Stai usando il logo del sito' . ( '' === $logo ? ' (non ne ho trovato uno: scegline uno tu).' : '.' ) )
			. ' Compare sulla tessera e nelle pagine di verifica.</p></td></tr>';

		echo '<tr><th>Colore principale</th><td><label><input type="checkbox" name="primary_custom" value="1"' . checked( $p_own, true, false ) . '> Personalizza</label> '
			. '<input type="color" name="accent_color" value="' . esc_attr( $p_own ? (string) $s['accent_color'] : Assets::accent( '#2271b1' ) ) . '">'
			. '<p class="description">Tessera e pulsanti. Senza spunta si usa il colore principale del sito' . ( '' !== $site_p ? ' (ora: <code>' . esc_html( $site_p ) . '</code>)' : ' (non lo trovo: uso un blu neutro)' ) . '.</p></td></tr>';

		echo '<tr><th>Colore secondario</th><td><label><input type="checkbox" name="secondary_custom" value="1"' . checked( $s_own, true, false ) . '> Personalizza</label> '
			. '<input type="color" name="secondary_color" value="' . esc_attr( $s_own ? (string) $s['secondary_color'] : Assets::secondary( Assets::accent( '#2271b1' ) ) ) . '">'
			. '<p class="description">Filetto in alto sulla tessera e passaggio del mouse sui pulsanti. Senza spunta si usa il colore secondario del sito' . ( '' !== $site_s ? ' (ora: <code>' . esc_html( $site_s ) . '</code>)' : ' (non lo trovo: il filetto ha il colore principale)' ) . '.</p></td></tr>';
		echo '</tbody></table>';
		self::card_section( $s );
		submit_button( 'Salva' );
		Ui::form_close();

		$acc = Assets::accent( '#2271b1' );
		$sec = Assets::secondary( $acc );
		echo '<h2>Anteprima della tessera</h2><div style="max-width:380px;border-radius:14px;padding:20px 24px;background:#fff;color:' . esc_attr( $acc ) . ';border:2px solid ' . esc_attr( $acc ) . ';border-top:8px solid ' . esc_attr( $sec ) . '">'
			. ( '' !== $logo ? '<img src="' . esc_url( $logo ) . '" alt="" style="display:block;max-height:52px;max-width:190px;margin:0 0 10px">' : '' )
			. '<div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase">' . esc_html( (string) Settings::get( 'association_name' ) ) . '</div>'
			. '<div style="font-size:24px;font-weight:700;margin-top:6px">Nome Cognome</div><div style="opacity:.9">Socio ordinario</div>'
			. '<div style="display:flex;gap:32px;margin-top:14px"><div><div style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;opacity:.8">Tessera n.</div><div style="font-size:20px;font-weight:600">123</div></div>'
			. '<div><div style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;opacity:.8">Valida fino al</div><div style="font-size:20px;font-weight:600">31/12/' . ( (int) current_time( 'Y' ) + 1 ) . '</div></div></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<script>(function(){var pick=document.getElementById("apse-logo-pick"),clr=document.getElementById("apse-logo-clear"),id=document.getElementById("apse-logo-id"),pv=document.getElementById("apse-logo-preview"),f;'
			. 'if(!pick||!window.wp||!wp.media){return;}'
			. 'pick.addEventListener("click",function(e){e.preventDefault();if(!f){f=wp.media({title:"Logo dell\'ente",button:{text:"Usa questo logo"},library:{type:"image"},multiple:false});'
			. 'f.on("select",function(){var a=f.state().get("selection").first().toJSON();id.value=a.id;var u=(a.sizes&&a.sizes.medium)?a.sizes.medium.url:a.url;pv.innerHTML="<img src=\""+u+"\" alt=\"\" style=\"max-height:56px;max-width:220px;display:block\">";clr.style.display="";});}f.open();});'
			. 'clr.addEventListener("click",function(e){e.preventDefault();id.value="0";pv.innerHTML="<span class=\"description\">Sarà usato il logo del sito dopo il salvataggio</span>";clr.style.display="none";});})();</script>';
		Ui::footer();
	}
}
