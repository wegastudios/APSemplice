<?php
namespace ApSemplice\Frontend;

defined( 'ABSPATH' ) || exit;

/** Avvio del front-end: shortcode, contenuti riservati, azioni dei soci, blocchi Gutenberg, widget Elementor. */
final class Front {

	public static function init(): void {
		Shortcodes::register();
		Restrict::register();
		Actions::register();
		if ( \ApSemplice\Edition::installed( 'payments' ) ) {
			PayReturn::register();
		}
		CardVerify::register();
		TicketVerify::register();
		Activation::register();
		FirstAccess::register();
		\ApSemplice\Calendar::register();
		Blocks::register();
		ElementorSupport::register();
	}
}
