<?php
namespace AssociazioneSemplice\Admin;

use AssociazioneSemplice\Plugin;
use AssociazioneSemplice\Privacy;
use AssociazioneSemplice\Reminders;
use AssociazioneSemplice\Settings;

defined( 'ABSPATH' ) || exit;

/** Impostazioni → Promemoria, privacy, regolamento e ricevute. */
final class CommsPage {

	public static function render(): void {
		$s = Settings::all();
		Ui::header( 'Promemoria, privacy, regolamento e ricevute' );
		Ui::form_open( 'asem_save_comms', Ui::url( 'asem-comms' ) );
		echo '<h2>Promemoria per email</h2><p class="description">Ogni giorno il sito invia i promemoria ai soci. Sono disattivati finché non li attivi. Chi non ha un indirizzo email (un ospite) riceve il messaggio tramite il socio che lo ospita; ogni promemoria viene inviato una sola volta.</p>';
		echo '<table class="form-table"><tbody>';
		echo '<tr><th>Promemoria attivi</th><td><label><input type="checkbox" name="reminders_enabled" value="1"' . checked( ! empty( $s['reminders_enabled'] ), true, false ) . '> Invia i promemoria ogni giorno</label></td></tr>';
		echo '<tr><th>Tessera</th><td><label><input type="checkbox" name="reminders_membership" value="1"' . checked( ! empty( $s['reminders_membership'] ), true, false ) . '> Tessera in scadenza e scaduta da poco</label> '
			. '— avvisa <input type="number" min="1" max="120" name="reminders_membership_days" value="' . (int) $s['reminders_membership_days'] . '" style="width:70px"> giorni prima</td></tr>';
		echo '<tr><th>Mensilità dei corsi</th><td><label><input type="checkbox" name="reminders_dues" value="1"' . checked( ! empty( $s['reminders_dues'] ), true, false ) . '> Rinnovo dei corsi mensili</label> <span class="description">Dopo l\'ultima lezione del mese si ricorda a chi non ha ancora pagato il mese dopo (i corsi si rinnovano a inizio mese). Senza orari di lezione, dal 25 del mese. Un messaggio per persona, corso e mese.</span></td></tr>';
		echo '<tr><th>Eventi</th><td><label><input type="checkbox" name="reminders_events" value="1"' . checked( ! empty( $s['reminders_events'] ), true, false ) . '> Promemoria il giorno prima a chi è prenotato</label></td></tr>';
		echo '</tbody></table>';

		echo '<h2>Privacy</h2><table class="form-table"><tbody>';
		echo '<tr><th>Pagina dell\'informativa</th><td><input type="url" name="privacy_url" value="' . esc_attr( (string) $s['privacy_url'] ) . '" class="regular-text" placeholder="https://…/privacy">'
			. '<p class="description">Se la indichi, chi attiva il proprio accesso deve accettarla e il consenso viene registrato. Per gli altri soci registri il consenso dalla loro scheda (modulo cartaceo, a voce…).</p></td></tr>';
		echo '<tr><th>Email per la privacy</th><td><input type="email" name="privacy_email" value="' . esc_attr( (string) $s['privacy_email'] ) . '" class="regular-text" placeholder="privacy@…">'
			. '<p class="description">L\'indirizzo a cui scrivere per esercitare i diritti: compare nell\'informativa. Se lo lasci vuoto si usa la PEC dell\'ente.</p></td></tr>';
		echo '<tr><th>Ex soci da anonimizzare</th><td>dopo <input type="number" min="1" max="30" name="privacy_retention_years" value="' . (int) $s['privacy_retention_years'] . '" style="width:70px"> anni di inattività<p class="description">Tempo oltre il quale proponi di togliere i dati personali di chi non partecipa più. Decidi tu caso per caso: i movimenti contabili restano.</p></td></tr>';
		echo '</tbody></table>';

		echo '<h2>Regolamento</h2><p class="description">Facoltativo: se lo attivi, chi si iscrive online deve accettarlo (e chi è già socio lo trova in cima alla propria area). Per chi si iscrive di persona registri l\'accettazione dalla scheda del socio.</p><table class="form-table"><tbody>';
		echo '<tr><th>Regolamento attivo</th><td><label><input type="checkbox" name="rules_enabled" value="1"' . checked( ! empty( $s['rules_enabled'] ), true, false ) . '> Richiedi l\'accettazione ai soci</label></td></tr>';
		echo '<tr><th>Titolo</th><td><input type="text" name="rules_title" value="' . esc_attr( (string) $s['rules_title'] ) . '" class="regular-text" placeholder="Regolamento"></td></tr>';
		echo '<tr><th>Testo</th><td><textarea name="rules_text" rows="8" class="large-text">' . esc_textarea( (string) $s['rules_text'] ) . '</textarea><p class="description">Si mostra in un riquadro scorrevole. In alternativa (o in aggiunta) indica qui sotto la pagina del sito che lo contiene.</p></td></tr>';
		echo '<tr><th>Pagina del regolamento</th><td><input type="url" name="rules_url" value="' . esc_attr( (string) $s['rules_url'] ) . '" class="regular-text" placeholder="https://…/regolamento"></td></tr>';
		echo '<tr><th>Versione</th><td><input type="text" name="rules_version" value="' . esc_attr( (string) $s['rules_version'] ) . '" maxlength="20" style="width:120px"><p class="description">Quando modifichi il regolamento cambia la versione (ad esempio 2): tutti i soci dovranno accettarlo di nuovo.</p></td></tr>';
		echo '<tr><th>Prenotazioni</th><td><label><input type="checkbox" name="rules_block_booking" value="1"' . checked( ! empty( $s['rules_block_booking'] ), true, false ) . '> Senza accettazione il socio non può prenotare</label></td></tr>';
		echo '</tbody></table>';

		echo '<h2>Ricevute</h2><table class="form-table"><tbody>';
		echo '<tr><th>Riga in fondo alla ricevuta</th><td><textarea name="receipt_footer" rows="2" class="large-text" maxlength="300">' . esc_textarea( (string) $s['receipt_footer'] ) . '</textarea>'
			. '<p class="description">Facoltativa: ad esempio il riferimento normativo che il tuo consulente ti indica per le quote associative. Le ricevute le trovi accanto a ogni incasso della Prima nota e nella scheda del socio; i soci le scaricano dalla loro area.</p></td></tr>';
		echo '</tbody></table>';
		submit_button( 'Salva' );
		Ui::form_close();

		// Informativa privacy compilata con i dati dell'ente
		$pn_missing = \AssociazioneSemplice\PrivacyNotice::missing();
		$pn_resp    = \AssociazioneSemplice\PrivacyNotice::responsible();
		echo '<h2>Informativa privacy</h2><p class="description">Il modello dell\'informativa (artt. 13 e 14 GDPR) si compila da solo con i dati dell\'ente e con le funzioni che usi: dichiara che i dati si comunicano a terzi solo per le finalità degli eventi cui si partecipa, che non vengono ceduti per scopi commerciali e che il trattamento avviene con strumenti informatici, senza profilazione commerciale. Responsabile del trattamento è il presidente; in mancanza, il socio con il ruolo di segreteria. È un modello: fallo leggere al tuo consulente prima di pubblicarlo.</p>';
		echo '<p><strong>Responsabile del trattamento:</strong> ' . esc_html( $pn_resp['name'] ) . ( $pn_resp['found'] ? ' (' . esc_html( $pn_resp['role'] ) . ')' : '' ) . '</p>';
		if ( $pn_missing ) {
			echo '<div class="notice notice-warning inline"><p>Da completare per avere un\'informativa precisa: <strong>' . esc_html( implode( ', ', $pn_missing ) ) . '</strong>. I dati dell\'ente si inseriscono in <a href="' . esc_url( Ui::url( 'asem-entity' ) ) . '">Dati e fiscalità</a> (e il presidente dalla scheda del socio, riquadro «Consiglio direttivo»).</p></div>';
		}
		echo '<p><a class="button button-primary" href="' . esc_url( \AssociazioneSemplice\Docs::url( 'privacy' ) ) . '" target="_blank" rel="noopener">Scarica il PDF (con la firma di presa visione)</a> ';
		Ui::form_open( 'asem_create_privacy_page', Ui::url( 'asem-comms' ), false, 'asem-inline' );
		echo '<button class="button">Crea la pagina «Informativa privacy» sul sito</button>';
		Ui::form_close();
		echo '</p><details><summary><strong>Anteprima dell\'informativa</strong></summary><div style="max-width:820px;background:#fff;padding:12px 20px;border:1px solid #c3c4c7">' . \AssociazioneSemplice\PrivacyNotice::html() . '</div></details>'; // phpcs:ignore WordPress.Security.EscapeOutput -- html già protetto da PrivacyNotice

		// Promemoria: anteprima e invio manuale
		echo '<h2>Promemoria di oggi</h2>';
		$prev = Reminders::run( null, false );
		echo '<p>Da mandare adesso: <strong>' . (int) $prev['membership'] . '</strong> per la tessera · <strong>' . (int) $prev['dues'] . '</strong> per le mensilità · <strong>' . (int) $prev['events'] . '</strong> per gli eventi di domani. ';
		$last = Reminders::last_run();
		echo $last ? '<span class="description">Ultimo invio: ' . esc_html( mysql2date( 'd/m/Y H:i', $last['at'] ) ) . '.</span>' : '<span class="description">Nessun invio finora.</span>';
		echo '</p>';
		Ui::form_open( 'asem_reminders_run', Ui::url( 'asem-comms' ), false, 'asem-inline' );
		echo '<button class="button"' . ( Reminders::enabled() ? '' : ' disabled' ) . ' data-confirm="Mandare ora i promemoria?">Invia ora</button>';
		Ui::form_close();
		if ( ! Reminders::enabled() ) {
			echo ' <span class="description">Attiva i promemoria e salva per poterli inviare.</span>';
		}

		// Privacy: consensi e anonimizzazione
		$people = Plugin::people()->search( array( 'status' => 'noconsent' ) );
		echo '<h2>Consenso privacy</h2><p>Persone senza consenso registrato: <strong>' . count( $people ) . '</strong> '
			. '<a href="' . esc_url( Ui::url( 'asem-people', array( 'status' => 'noconsent' ) ) ) . '">vedi l\'elenco</a></p>';
		$cands = Privacy::retention_candidates();
		echo '<h2>Ex soci da anonimizzare (' . count( $cands ) . ')</h2>';
		if ( ! $cands ) {
			echo '<p class="description">Nessuno: non ci sono persone inattive da più di ' . (int) $s['privacy_retention_years'] . ' anni (o hanno ancora prenotazioni, iscrizioni o ospiti).</p>';
		} else {
			echo '<p class="description">Persone senza attività da oltre ' . (int) $s['privacy_retention_years'] . ' anni. «Anonimizza» toglie nome, contatti, codice fiscale, tessera e note; i movimenti contabili restano. Non si può annullare.</p><ul>';
			foreach ( $cands as $c ) {
				echo '<li><a href="' . esc_url( Ui::url( 'asem-person', array( 'id' => $c['id'] ) ) ) . '">' . esc_html( $c['name'] ) . '</a> <span class="description">ultima attività ' . esc_html( Ui::date( $c['last_seen'] ) ) . '</span> ';
				Ui::form_open( 'asem_privacy_anonymize', Ui::url( 'asem-comms' ), false, 'asem-inline' );
				echo Ui::hidden( 'id', $c['id'] ) . '<button class="button button-small" data-confirm="Anonimizzare ' . esc_attr( $c['name'] ) . '? I suoi dati personali vengono tolti e non si possono recuperare.">Anonimizza</button>'; // phpcs:ignore WordPress.Security.EscapeOutput
				Ui::form_close();
				echo '</li>';
			}
			echo '</ul>';
		}
		Ui::footer();
	}
}
