<?php
namespace AssociazioneSemplice\Frontend;

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode `[associazionesemplice_*]`: funzionano in qualunque punto (Gutenberg blocco "Shortcode", Elementor widget
 * "Shortcode", editor classico, template). Blocchi Gutenberg e widget Elementor usano le stesse viste.
 *
 *  [associazionesemplice_area_soci sezioni="tessera,attivita,ospiti,profilo,volontario"]
 *  [associazionesemplice_tessera] [associazionesemplice_mie_attivita] [associazionesemplice_ospiti] [associazionesemplice_profilo] [associazionesemplice_area_volontari]
 *  [associazionesemplice_attivita anno="2025/2026" tipo="corso|evento|ricorrente" id="12" date="5"]
 *  [associazionesemplice_prossimi_eventi limite="5" prenotazione="si|no"]
 *  [associazionesemplice_accesso]
 *  [associazionesemplice_riservato accesso="soci|volontari|attivita" attivita="12,13"]…[/associazionesemplice_riservato]   (vedi Restrict)
 */
final class Shortcodes {

	/** Viste disponibili: slug => etichetta. */
	const VIEWS = array(
		'area_soci'       => 'Area soci (tessera, attività, ospiti, profilo)',
		'tessera'         => 'Tessera digitale',
		'mie_attivita'    => 'Le mie attività e prenotazioni',
		'pagamenti'       => 'Pagamenti da fare (e, se attivi, pagamento online)',
		'ricevute'        => 'Le mie ricevute e attestazioni (PDF)',
		'regolamento'     => 'Regolamento da accettare',
		'segreteria'      => 'Area segreteria (richieste, soci, comunicazioni)',
		'tesoriere'       => 'Area tesoriere (incassi, spese, iscrizioni, vendita eventi)',
		'spese'           => 'Spese del tesoriere (nome precedente di «Area tesoriere»)',
		'ingressi'        => 'Ingressi agli eventi (prenotati e QR, per responsabile e staff)',
		'avvisi'          => 'Avvisi dei volontari agli iscritti (bacheca)',
		'ospiti'          => 'I miei ospiti',
		'profilo'         => 'Il mio profilo',
		'area_volontari'  => 'Area volontari (le attività di cui sei referente)',
		'calendario'      => 'Calendario di corsi ed eventi (soci)',
		'attivita'        => 'Elenco attività ed eventi (pubblico)',
		'prossimi_eventi' => 'Prossimi eventi (pubblico)',
		'app'             => 'App e notifiche (installazione e notifiche sul telefono)',
		'cinquepermille'  => '5x1000 (messaggio pubblico con il codice fiscale)',
		'bonifico'        => 'Coordinate per il bonifico (pubblico, se attivo)',
		'donazioni'       => 'Donazioni con PayPal (pubblico, se attive)',
		'privacy'         => 'Informativa privacy (pubblico, compilata con i dati dell\'ente)',
		'accesso'         => 'Accesso / login',
	);

	/** Vista => funzione avanzata che la rende utile: senza la funzione non si propone nei blocchi, nei widget e nell'elenco. */
	const NEEDS = array( 'ricevute' => 'receipts', 'app' => 'pwa', 'cinquepermille' => 'fivepm' );

	public static function available( string $view ): bool {
		return ! isset( self::NEEDS[ $view ] ) || \AssociazioneSemplice\Edition::has( self::NEEDS[ $view ] );
	}

	public static function register(): void {
		foreach ( array_keys( self::VIEWS ) as $view ) {
			add_shortcode(
				'associazionesemplice_' . $view,
				function ( $atts ) use ( $view ) {
					return self::render_view( $view, (array) $atts );
				}
			);
		}
	}

	/** Disegna una vista. Usato da shortcode, blocco e widget. */
	public static function render_view( string $view, array $atts = array() ): string {
		switch ( $view ) {
			case 'area_soci':
				return Views::area( shortcode_atts( array( 'sezioni' => '' ), $atts ) );
			case 'tessera':
				return Views::card();
			case 'calendario':
				return Views::calendar();
			case 'avvisi':
				return Views::notices();
			case 'ingressi':
				return Views::checkin();
			case 'spese':
			case 'tesoriere':
				return Views::expenses();
			case 'segreteria':
				return Views::secretary();
			case 'regolamento':
				return Views::rules();
			case 'ricevute':
				return Views::receipts();
			case 'pagamenti':
				return Views::pay();
			case 'mie_attivita':
				return Views::my_activities();
			case 'ospiti':
				return Views::guests();
			case 'profilo':
				return Views::profile();
			case 'area_volontari':
				return Views::volunteer();
			case 'attivita':
				return Views::activities( shortcode_atts( array( 'anno' => '', 'tipo' => '', 'id' => '', 'date' => '5' ), $atts ) );
			case 'prossimi_eventi':
				return Views::upcoming( shortcode_atts( array( 'limite' => '5', 'prenotazione' => 'si' ), $atts ) );
			case 'app':
				return Views::app();
			case 'cinquepermille':
				return Views::five_per_mille();
			case 'bonifico':
				return Views::bank_public();
			case 'donazioni':
				return Views::donate();
			case 'privacy':
				return Views::privacy_notice();
			case 'accesso':
				return is_user_logged_in() ? '' : Views::login_prompt();
		}
		return '';
	}
}
