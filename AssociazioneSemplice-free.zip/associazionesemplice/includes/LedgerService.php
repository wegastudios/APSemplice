<?php
namespace AssociazioneSemplice;

defined( 'ABSPATH' ) || exit;

/**
 * Prima nota, conti e cassa.
 *
 * Regole:
 *  - importi in centesimi, sempre positivi; il segno viene dal tipo di movimento;
 *  - il saldo di un conto è calcolato (saldo iniziale + movimenti), mai memorizzato;
 *  - i movimenti non si modificano: si annullano (voided_at + motivo) e si reinseriscono;
 *  - un giroconto sono due righe con lo stesso transfer_id: non è né entrata né uscita;
 *  - un incasso con più voci sono più righe con lo stesso receipt_id.
 */
class LedgerService {

	private function db(): \wpdb {
		return Db::db();
	}

	// ---------- Conti e categorie ----------

	/** Conti aperti (di default) oppure anche quelli chiusi. */
	public function accounts( bool $with_closed = false ): array {
		return $this->db()->get_results( 'SELECT * FROM ' . Db::t( 'accounts' ) . ' WHERE deleted_at IS NULL' . ( $with_closed ? '' : ' AND closed_at IS NULL' ) . ' ORDER BY sort_order, name', ARRAY_A ) ?: array();
	}

	/** Un conto aperto (i conti chiusi non accettano nuovi movimenti). */
	public function account( int $id ): ?array {
		$row = $this->account_any( $id );
		return $row && null === $row['closed_at'] ? $row : null;
	}

	/** Un conto anche se chiuso. */
	public function account_any( int $id ): ?array {
		$row = $this->db()->get_row( $this->db()->prepare( 'SELECT * FROM ' . Db::t( 'accounts' ) . ' WHERE id = %d AND deleted_at IS NULL', $id ), ARRAY_A );
		return $row ?: null;
	}

	private function check_account_fields( string $name, string $type ): string {
		$name = trim( $name );
		if ( '' === $name ) {
			throw new \InvalidArgumentException( 'Il nome del conto è obbligatorio.' );
		}
		if ( ! isset( Labels::account_types()[ $type ] ) ) {
			throw new \InvalidArgumentException( 'Tipo di conto non valido.' );
		}
		return $name;
	}

	public function add_account( string $name, string $type, int $opening_cents ): int {
		$name = $this->check_account_fields( $name, $type );
		$this->db()->insert( Db::t( 'accounts' ), array( 'name' => $name, 'type' => $type, 'opening_cents' => $opening_cents, 'sort_order' => count( $this->accounts( true ) ) ) );
		return (int) $this->db()->insert_id;
	}

	/** Rinomina e cambia tipo e saldo di partenza: i saldi si ricalcolano da soli. */
	public function update_account( int $id, string $name, string $type, int $opening_cents ): void {
		$old = $this->account_any( $id );
		if ( ! $old ) {
			throw new \InvalidArgumentException( 'Conto non trovato.' );
		}
		$name = $this->check_account_fields( $name, $type );
		$this->db()->update( Db::t( 'accounts' ), array( 'name' => $name, 'type' => $type, 'opening_cents' => $opening_cents ), array( 'id' => $id ) );
		$details = array();
		foreach ( array( 'name' => $name, 'type' => $type ) as $k => $v ) {
			if ( $old[ $k ] !== $v ) {
				$details[ $k ] = array( $old[ $k ], $v );
			}
		}
		if ( (int) $old['opening_cents'] !== $opening_cents ) {
			$details['opening_cents'] = array( (int) $old['opening_cents'], $opening_cents );
		}
		Audit::log( 'account.updated', 'account', $id, $details );
	}

	/** Chiude un conto: deve essere a zero (altrimenti sposta prima i soldi con un giroconto). */
	public function close_account( int $id ): void {
		$acc = $this->account( $id );
		if ( ! $acc ) {
			throw new \InvalidArgumentException( 'Conto non trovato o già chiuso.' );
		}
		$balance = 0;
		foreach ( $this->balances() as $b ) {
			if ( (int) $b['id'] === $id ) {
				$balance = $b['balance'];
			}
		}
		if ( 0 !== $balance ) {
			throw new \InvalidArgumentException( 'Il conto ha ancora ' . Money::format( $balance ) . ': spostali con un giroconto (o rettifica il saldo) prima di chiuderlo.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
		}
		$this->db()->update( Db::t( 'accounts' ), array( 'closed_at' => Db::now() ), array( 'id' => $id ) );
		Audit::log( 'account.closed', 'account', $id );
	}

	public function reopen_account( int $id ): void {
		if ( ! $this->account_any( $id ) ) {
			throw new \InvalidArgumentException( 'Conto non trovato.' );
		}
		$this->db()->update( Db::t( 'accounts' ), array( 'closed_at' => null ), array( 'id' => $id ) );
		Audit::log( 'account.reopened', 'account', $id );
	}

	/** Conto "Stripe" / "PayPal" in cui entrano gli incassi online (creato al primo pagamento). */
	public function online_account( string $provider ): int {
		$names = array( 'paypal' => 'PayPal', 'woocommerce' => 'WooCommerce' );
		$name  = $names[ $provider ] ?? 'Stripe';
		foreach ( $this->accounts() as $a ) {
			if ( $a['name'] === $name ) {
				return (int) $a['id'];
			}
		}
		return $this->add_account( $name, 'other', 0 );
	}

	public function categories(): array {
		return $this->db()->get_results( 'SELECT * FROM ' . Db::t( 'categories' ) . ' WHERE deleted_at IS NULL ORDER BY name', ARRAY_A ) ?: array();
	}

	private function category( int $id ): ?array {
		$row = $this->db()->get_row( $this->db()->prepare( 'SELECT * FROM ' . Db::t( 'categories' ) . ' WHERE id = %d AND deleted_at IS NULL', $id ), ARRAY_A );
		return $row ?: null;
	}

	public function category_id_of_kind( string $kind ): int {
		return (int) $this->db()->get_var( $this->db()->prepare( 'SELECT id FROM ' . Db::t( 'categories' ) . ' WHERE kind = %s AND deleted_at IS NULL LIMIT 1', $kind ) );
	}

	/** Conto più adatto alla modalità di pagamento: contanti->cassa, POS->conto POS, altro->banca. */
	public function default_account_for( string $method ): ?array {
		$wanted = 'cash' === $method ? 'cash' : ( 'pos' === $method ? 'pos' : 'bank' );
		$all    = $this->accounts();
		foreach ( $all as $a ) {
			if ( $a['type'] === $wanted ) {
				return $a;
			}
		}
		return $all[0] ?? null;
	}

	// ---------- Saldi ----------

	private function deltas( ?string $up_to ): array {
		$sql = "SELECT account_id, SUM(CASE WHEN type IN ('income','transfer_in') THEN amount_cents ELSE -amount_cents END) AS delta "
			. 'FROM ' . Db::t( 'transactions' ) . ' WHERE voided_at IS NULL';
		if ( null !== $up_to ) {
			$sql = $this->db()->prepare( $sql . ' AND tx_date <= %s', $up_to );
		}
		$out = array();
		foreach ( $this->db()->get_results( $sql . ' GROUP BY account_id', ARRAY_A ) ?: array() as $r ) {
			$out[ (int) $r['account_id'] ] = (int) $r['delta'];
		}
		return $out;
	}

	/** Conti con il saldo calcolato (a oggi, oppure fino a una data inclusa). */
	public function balances( ?string $up_to = null, bool $with_closed = false ): array {
		$deltas = $this->deltas( $up_to );
		$out    = array();
		foreach ( $this->accounts( $with_closed ) as $a ) {
			$a['balance'] = (int) $a['opening_cents'] + ( $deltas[ (int) $a['id'] ] ?? 0 );
			$out[]        = $a;
		}
		return $out;
	}

	public function expected_balance( int $account_id, string $up_to ): int {
		foreach ( $this->balances( $up_to ) as $a ) {
			if ( (int) $a['id'] === $account_id ) {
				return $a['balance'];
			}
		}
		return 0;
	}

	// ---------- Registrazione ----------

	private function assert_date( string $d ): void {
		$dt = \DateTime::createFromFormat( 'Y-m-d', $d );
		if ( ! $dt || $dt->format( 'Y-m-d' ) !== $d ) {
			throw new \InvalidArgumentException( 'Data non valida.' );
		}
	}

	/** Controlla il conto e restituisce la modalità di pagamento: se non è indicata, la decide il conto (cassa = contanti, conto = bonifico, POS = carta). */
	private function assert_account_method( int $account_id, string $method ): string {
		$account = $this->account( $account_id );
		if ( ! $account ) {
			throw new \InvalidArgumentException( $this->account_any( $account_id ) ? 'Il conto è chiuso: riaprilo per registrare movimenti.' : 'Conto non valido.' );
		}
		if ( '' === trim( $method ) ) {
			return Labels::method_for_account( (string) $account['type'] );
		}
		if ( ! isset( Labels::methods()[ $method ] ) ) {
			throw new \InvalidArgumentException( 'Modalità di pagamento non valida.' );
		}
		return $method;
	}

	private function tx_defaults( array $extra ): array {
		return array_merge(
			array(
				'description' => '', 'created_by' => get_current_user_id() ?: null, 'created_at' => Db::now(),
			),
			$extra
		);
	}

	private function insert_tx( array $row ): int {
		if ( ! $this->db()->insert( Db::t( 'transactions' ), $this->tx_defaults( $row ) ) ) {
			throw new \RuntimeException( 'Errore del database nel salvare il movimento.' );
		}
		$id = (int) $this->db()->insert_id;
		Audit::log( 'tx.created', 'transaction', $id, array( 'type' => $row['type'], 'cents' => (int) $row['amount_cents'], 'account' => (int) $row['account_id'] ) );
		return $id;
	}

	/** Profondità della transazione in corso: una transazione dentro un'altra si unisce alla prima (altrimenti MySQL conferma subito la prima). */
	private $tx_depth = 0;

	private function in_transaction( callable $fn ) {
		if ( $this->tx_depth > 0 ) {
			return $fn();
		}
		$this->tx_depth++;
		$this->db()->query( 'START TRANSACTION' );
		try {
			$res = $fn();
			$this->db()->query( 'COMMIT' );
			return $res;
		} catch ( \Throwable $e ) {
			$this->db()->query( 'ROLLBACK' );
			throw $e;
		} finally {
			$this->tx_depth--;
		}
	}

	/**
	 * Incasso da una persona: una o più voci, un solo conto e una sola modalità.
	 *
	 * @param array $d date, account_id, method, person_id?, document_ref?, lines[]: category_id, amount_cents,
	 *                 activity_id?, competence_month?, social_year?, description?
	 * @return int numero di righe registrate
	 */
	public function record_receipt( array $d ): int {
		$date = (string) ( $d['date'] ?? '' );
		$this->assert_date( $date );
		FiscalYears::assert_open_for_date( $date );
		$d['method'] = $this->assert_account_method( (int) ( $d['account_id'] ?? 0 ), (string) ( $d['method'] ?? '' ) );
		$lines = $d['lines'] ?? array();
		if ( ! $lines ) {
			throw new \InvalidArgumentException( 'Aggiungi almeno una voce all\'incasso.' );
		}
		$payer = ! empty( $d['person_id'] ) ? Plugin::people()->get( (int) $d['person_id'] ) : null; // chi paga
		if ( ! empty( $d['person_id'] ) && ! $payer ) {
			throw new \InvalidArgumentException( 'Persona non trovata.' );
		}

		// Validazione completa prima di scrivere
		$prepared = array();
		foreach ( $lines as $i => $l ) {
			$n      = $i + 1;
			// Ogni voce vale per un beneficiario: di norma chi paga, ma si può pagare per altri (familiari, ospiti, altri soci)
			$person = $payer;
			if ( ! empty( $l['person_id'] ) && ( ! $payer || (int) $l['person_id'] !== (int) $payer['id'] ) ) {
				$person = Plugin::people()->get( (int) $l['person_id'] );
				if ( ! $person ) {
					throw new \InvalidArgumentException( "Voce $n: persona non trovata." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
			}
			$cat  = $this->category( (int) ( $l['category_id'] ?? 0 ) );
			$cents = (int) ( $l['amount_cents'] ?? 0 );
			if ( ! $cat || ! Labels::category_kinds()[ $cat['kind'] ][1] || 'adjustment' === $cat['kind'] ) {
				throw new \InvalidArgumentException( "Voce $n: categoria non valida per un incasso." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			$discount = max( 0, (int) ( $l['discount_cents'] ?? 0 ) ); // sconto, promozione o arrotondamento: la voce conta come pagata anche se si incassa meno
			if ( $cents < 0 || ( $cents <= 0 && $discount <= 0 ) ) {
				throw new \InvalidArgumentException( "Voce $n: importo non valido." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			if ( ! empty( $l['competence_month'] ) && ! preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', $l['competence_month'] ) ) {
				throw new \InvalidArgumentException( "Voce $n: mese di competenza non valido." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			$activity_id = ! empty( $l['activity_id'] ) ? (int) $l['activity_id'] : null;
			$session_id  = ! empty( $l['session_id'] ) ? (int) $l['session_id'] : null;
			$activity    = $activity_id ? Plugin::activities()->get( $activity_id ) : null;
			if ( $activity_id && ! $activity ) {
				throw new \InvalidArgumentException( "Voce $n: attività non trovata." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			if ( $activity_id && ! $person ) {
				throw new \InvalidArgumentException( "Voce $n: indica chi paga il contributo dell'attività." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			if ( $session_id && ! $activity_id ) {
				throw new \InvalidArgumentException( "Voce $n: la data dell'evento richiede l'attività." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			if ( $activity && ActivityKind::uses_sessions( $activity['kind'] ) ) {
				// Eventi: il contributo si paga per una data a cui la persona è prenotata
				$session = $session_id ? Plugin::activities()->session( $session_id ) : null;
				if ( ! $session || (int) $session['activity_id'] !== $activity_id ) {
					throw new \InvalidArgumentException( "Voce $n: indica a quale data dell'evento si riferisce il contributo." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
				if ( ! Plugin::activities()->has_active_booking( $session_id, (int) $person['id'] ) ) {
					throw new \InvalidArgumentException( "Voce $n: la persona non è prenotata a questa data." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
			} elseif ( $session_id ) {
				throw new \InvalidArgumentException( "Voce $n: i corsi non hanno date: indica il mese di competenza." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
			}
			$social_year = null;
			$free_year   = null;
			if ( 'membership' === $cat['kind'] ) {
				if ( ! $person ) {
					throw new \InvalidArgumentException( "Voce $n: la quota associativa richiede di indicare il socio." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
				if ( MemberType::GUEST === $person['type'] ) {
					throw new \InvalidArgumentException( "Voce $n: un ospite non è socio e non paga la quota associativa." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
				if ( MemberType::is_auto_renewed( $person['type'] ) ) {
					throw new \InvalidArgumentException( "Voce $n: il socio fondatore ha la tessera sempre rinnovata." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
				if ( Plugin::people()->is_suspended( (int) $person['id'] ) ) {
					throw new \InvalidArgumentException( "Voce $n: il socio è sospeso (inattivo): riattivalo a mano dalla sua scheda prima di incassare la quota." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
				// La quota va all'anno più recente creato; se non è quello in corso, l'anno in corso è in omaggio (a chi non è un socio scaduto).
				$plan        = Plugin::people()->membership_plan( (int) $person['id'], $date );
				$social_year = ! empty( $l['social_year'] ) ? (string) $l['social_year'] : $plan['year'];
				if ( ! preg_match( '#^(19|20)\d{2}(/(19|20)\d{2})?$#', $social_year ) ) {
					throw new \InvalidArgumentException( "Voce $n: anno della tessera non valido." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messaggio interno, mostrato solo dopo esc_html
				}
				$free_year   = $social_year === $plan['year'] ? $plan['free'] : null;
			}
			// IVA: esplicita se indicata, altrimenti quella della quota associativa o dell'attività (solo se l'ente applica l'IVA)
				$vat_rate = null;
				if ( Fiscal::vat_applies() ) {
					if ( array_key_exists( 'vat_rate', $l ) ) {
						$vat_rate = Fiscal::clean_rate( $l['vat_rate'] );
					} elseif ( 'membership' === $cat['kind'] ) {
						$vat_rate = Fiscal::membership_rate();
					} elseif ( $activity ) {
						$vat_rate = Fiscal::activity_rate( $activity );
					}
				}
				if ( null !== $vat_rate && Fiscal::EXCLUDED === (string) ( $l['vat_mode'] ?? '' ) ) {
					$cents = Fiscal::gross_from_input( $cents, $vat_rate, Fiscal::EXCLUDED ); // importo scritto IVA esclusa: si incassa con l'IVA
				}
				$prepared[] = array( 'vat_rate' => $vat_rate, 'cat' => $cat, 'cents' => $cents, 'discount' => $discount, 'activity_id' => $activity_id, 'session_id' => $session_id, 'social_year' => $social_year, 'free_year' => $free_year, 'person' => $person, 'line' => $l );
		}

		$receipt_id = wp_generate_uuid4();
		return $this->in_transaction(
			function () use ( $prepared, $d, $date, $payer, $receipt_id ) {
				foreach ( $prepared as $p ) {
					$tx_id = $this->insert_tx(
						array(
							'tx_date'          => $date,
							'type'             => 'income',
							'amount_cents'     => $p['cents'],
							'account_id'       => (int) $d['account_id'],
							'method'           => $d['method'],
							'category_id'      => (int) $p['cat']['id'],
							'activity_id'      => $p['activity_id'],
							'session_id'       => $p['session_id'],
							'person_id'        => $p['person'] ? (int) $p['person']['id'] : null,
							'payer_person_id'  => $payer && $p['person'] && (int) $payer['id'] !== (int) $p['person']['id'] ? (int) $payer['id'] : null,
							'description'      => mb_substr( (string) ( $p['line']['description'] ?? '' ) . ( $p['discount'] > 0 ? ' · sconto ' . Money::format( $p['discount'] ) . ( '' !== trim( (string) ( $p['line']['discount_note'] ?? '' ) ) ? ' (' . trim( (string) $p['line']['discount_note'] ) . ')' : '' ) : '' ), 0, 255 ),
							'discount_cents'   => $p['discount'],
							'vat_rate'         => $p['vat_rate'],
							'vat_cents'        => Fiscal::vat_of( (int) $p['cents'], $p['vat_rate'] ),
							'competence_month' => ! empty( $p['line']['competence_month'] ) ? $p['line']['competence_month'] : null,
							'social_year'      => $p['social_year'],
							'document_ref'     => ! empty( $d['document_ref'] ) ? mb_substr( trim( $d['document_ref'] ), 0, 80 ) : null,
							'receipt_id'       => $receipt_id,
						)
					);
					if ( 'membership' === $p['cat']['kind'] ) {
						Plugin::people()->set_membership( (int) $p['person']['id'], $p['social_year'], true, 'payment', $tx_id );
						if ( ! empty( $p['free_year'] ) ) {
							Plugin::people()->set_membership( (int) $p['person']['id'], (string) $p['free_year'], true, 'promo', $tx_id ); // anno in corso in omaggio (se si annulla l'incasso, salta anche questo)
						}
					}
					if ( $p['activity_id'] ) {
						$activity = Plugin::activities()->get( (int) $p['activity_id'] );
						if ( $activity ) {
							Plugin::funds()->attribute( $tx_id, $activity, $p['cents'], $date ); // quota per il rimborso del volontario (se prevista)
						}
					}
				}
				return count( $prepared );
			}
		);
	}

	/** @param array $d date, account_id, method, category_id, amount_cents, activity_id?, person_id?, description?, document_ref? */
	public function record_expense( array $d ): int {
		$date = (string) ( $d['date'] ?? '' );
		$this->assert_date( $date );
		FiscalYears::assert_open_for_date( $date );
		$d['method'] = $this->assert_account_method( (int) ( $d['account_id'] ?? 0 ), (string) ( $d['method'] ?? '' ) );
		$cat = $this->category( (int) ( $d['category_id'] ?? 0 ) );
		if ( ! $cat || ! Labels::category_kinds()[ $cat['kind'] ][2] || 'adjustment' === $cat['kind'] ) {
			throw new \InvalidArgumentException( 'Categoria non valida per una spesa.' );
		}
		if ( (int) ( $d['amount_cents'] ?? 0 ) <= 0 ) {
			throw new \InvalidArgumentException( 'Importo non valido.' );
		}
		if ( ! empty( $d['activity_id'] ) && ! Plugin::activities()->get( (int) $d['activity_id'] ) ) {
			throw new \InvalidArgumentException( 'Attività non trovata.' );
		}
		$vat_rate = Fiscal::vat_applies() && array_key_exists( 'vat_rate', $d ) ? Fiscal::clean_rate( $d['vat_rate'] ) : null;
		$d['amount_cents'] = Fiscal::gross_from_input( (int) $d['amount_cents'], $vat_rate, (string) ( $d['vat_mode'] ?? '' ) ); // se l'importo è scritto IVA esclusa si paga con l'IVA
		return $this->insert_tx(
			array(
				'vat_rate'     => $vat_rate,
				'vat_cents'    => Fiscal::vat_of( (int) $d['amount_cents'], $vat_rate ),
				'tx_date'      => $date,
				'type'         => 'expense',
				'amount_cents' => (int) $d['amount_cents'],
				'account_id'   => (int) $d['account_id'],
				'method'       => $d['method'],
				'category_id'  => (int) $cat['id'],
				'activity_id'  => ! empty( $d['activity_id'] ) ? (int) $d['activity_id'] : null,
				'person_id'    => ! empty( $d['person_id'] ) ? (int) $d['person_id'] : null,
				'description'  => mb_substr( trim( (string) ( $d['description'] ?? '' ) ), 0, 255 ),
				'document_ref' => ! empty( $d['document_ref'] ) ? mb_substr( trim( $d['document_ref'] ), 0, 80 ) : null,
			)
		);
	}

	/** Giroconto tra due conti (versamento contanti in banca, accredito POS...). */
	public function record_transfer( string $date, int $from_id, int $to_id, int $cents, string $method, string $description = '' ): string {
		$this->assert_date( $date );
		FiscalYears::assert_open_for_date( $date );
		if ( $from_id === $to_id ) {
			throw new \InvalidArgumentException( 'Scegli due conti diversi.' );
		}
		$m_out = $this->assert_account_method( $from_id, $method );
		$m_in  = $this->assert_account_method( $to_id, $method );
		if ( $cents <= 0 ) {
			throw new \InvalidArgumentException( 'Importo non valido.' );
		}
		$cat      = $this->category_id_of_kind( 'adjustment' ); // segnaposto neutro per le righe di giroconto
		$transfer = wp_generate_uuid4();
		$this->in_transaction(
			function () use ( $date, $from_id, $to_id, $cents, $m_out, $m_in, $description, $cat, $transfer ) {
				foreach ( array( array( 'transfer_out', $from_id, $m_out ), array( 'transfer_in', $to_id, $m_in ) ) as $leg ) {
					$this->insert_tx(
						array(
							'tx_date' => $date, 'type' => $leg[0], 'amount_cents' => $cents, 'account_id' => $leg[1], 'method' => $leg[2],
							'category_id' => $cat, 'description' => mb_substr( $description, 0, 255 ), 'transfer_id' => $transfer,
						)
					);
				}
			}
		);
		return $transfer;
	}

	/** Annulla (senza cancellare) un movimento; per i giroconti annulla entrambe le righe. */
	public function void( int $tx_id, string $reason ): void {
		$tbl = Db::t( 'transactions' );
		$tx  = $this->db()->get_row( $this->db()->prepare( "SELECT * FROM $tbl WHERE id = %d AND voided_at IS NULL", $tx_id ), ARRAY_A );
		if ( ! $tx ) {
			throw new \InvalidArgumentException( 'Movimento non trovato o già annullato.' );
		}
		FiscalYears::assert_open_for_date( (string) $tx['tx_date'] ); // un anno solare chiuso non si modifica
		$ids = array( $tx_id );
		if ( ! empty( $tx['transfer_id'] ) ) {
			$ids = array_map( 'intval', $this->db()->get_col( $this->db()->prepare( "SELECT id FROM $tbl WHERE transfer_id = %s AND voided_at IS NULL", $tx['transfer_id'] ) ) );
		}
		$reason = '' === trim( $reason ) ? 'Annullato' : mb_substr( trim( $reason ), 0, 255 );
		$this->in_transaction(
			function () use ( $ids, $reason, $tbl ) {
				foreach ( $ids as $id ) {
					$this->db()->update( $tbl, array( 'voided_at' => Db::now(), 'void_reason' => $reason ), array( 'id' => $id ) );
					Plugin::people()->remove_membership_of_transaction( $id );
					Audit::log( 'tx.voided', 'transaction', $id, array( 'reason' => $reason ) );
				}
			}
		);
	}

	// ---------- Verifica cassa ----------

	/**
	 * Confronta il saldo dell'app con quello reale. Con $adjust crea la rettifica che riallinea l'app.
	 *
	 * @return int differenza (reale - app) in centesimi
	 */
	public function record_cash_count( int $account_id, string $date, int $counted_cents, bool $adjust, ?string $notes = null ): int {
		$this->assert_date( $date );
		if ( $adjust ) {
			FiscalYears::assert_open_for_date( $date );
		}
		$account = $this->account( $account_id );
		if ( ! $account ) {
			throw new \InvalidArgumentException( $this->account_any( $account_id ) ? 'Il conto è chiuso: riaprilo per registrare movimenti.' : 'Conto non valido.' );
		}
		return $this->in_transaction(
			function () use ( $account, $account_id, $date, $counted_cents, $adjust, $notes ) {
				$expected = $this->expected_balance( $account_id, $date );
				$diff     = $counted_cents - $expected;
				$adj_id   = null;
				if ( $adjust && 0 !== $diff ) {
					$adj_id = $this->insert_tx(
						array(
							'tx_date' => $date, 'type' => $diff > 0 ? 'income' : 'expense', 'amount_cents' => abs( $diff ),
							'account_id' => $account_id, 'method' => 'cash' === $account['type'] ? 'cash' : 'other',
							'category_id' => $this->category_id_of_kind( 'adjustment' ), 'description' => 'Rettifica da verifica saldo',
						)
					);
				}
				$this->db()->insert(
					Db::t( 'cash_counts' ),
					array(
						'account_id' => $account_id, 'count_date' => $date, 'counted_cents' => $counted_cents, 'expected_cents' => $expected,
						'difference_cents' => $diff, 'adjustment_tx_id' => $adj_id, 'notes' => $notes, 'created_at' => Db::now(),
					)
				);
				Audit::log( 'cashcount.recorded', 'account', $account_id, array( 'difference' => $diff, 'adjusted' => null !== $adj_id ) );
				return $diff;
			}
		);
	}

	// ---------- Lettura ----------

	/** Prima nota con i nomi risolti. $asc = ordine cronologico (per gli export). */
	public function rows( string $from, string $to, ?int $account_id = null, bool $asc = false ): array {
		$sql  = 'SELECT t.*, a.name AS account_name, c.name AS category_name, CONCAT(p.first_name, " ", p.last_name) AS person_name, '
			. 'p.card_number AS person_card, act.name AS activity_name, CONCAT(pp.first_name, " ", pp.last_name) AS payer_name FROM ' . Db::t( 'transactions' ) . ' t '
			. 'JOIN ' . Db::t( 'accounts' ) . ' a ON a.id = t.account_id '
			. 'JOIN ' . Db::t( 'categories' ) . ' c ON c.id = t.category_id '
			. 'LEFT JOIN ' . Db::t( 'people' ) . ' p ON p.id = t.person_id '
			. 'LEFT JOIN ' . Db::t( 'people' ) . ' pp ON pp.id = t.payer_person_id '
			. 'LEFT JOIN ' . Db::t( 'activities' ) . ' act ON act.id = t.activity_id '
			. 'WHERE t.voided_at IS NULL AND t.tx_date BETWEEN %s AND %s';
		$args = array( $from, $to );
		if ( $account_id ) {
			$sql   .= ' AND t.account_id = %d';
			$args[] = $account_id;
		}
		$sql .= $asc ? ' ORDER BY t.tx_date, t.id' : ' ORDER BY t.tx_date DESC, t.id DESC';
		return $this->db()->get_results( $this->db()->prepare( $sql, $args ), ARRAY_A ) ?: array();
	}

	// ---------- Import storico ----------

	/** Esegue più operazioni in un'unica transazione del database (tutto o niente). */
	public function in_batch( callable $fn ) {
		return $this->in_transaction( $fn );
	}

	/**
	 * Movimento da import (Excel/CSV): entra in prima nota così com'è, senza i controlli di un incasso dal vivo
	 * (le regole sono già state applicate dal piano di importazione).
	 *
	 * @param array $d date, type (income|expense), cents, account_id, method, category_id, activity_id?, person_id?, description?, ref?, month?
	 * @return int id del movimento
	 */
	public function import_row( array $d ): int {
		$this->assert_date( (string) $d['date'] );
		FiscalYears::assert_open_for_date( (string) $d['date'] );
		$d['method'] = $this->assert_account_method( (int) $d['account_id'], (string) $d['method'] );
		if ( ! in_array( $d['type'], array( 'income', 'expense' ), true ) || (int) $d['cents'] <= 0 ) {
			throw new \InvalidArgumentException( 'Movimento non valido.' );
		}
		$cat = $this->category( (int) $d['category_id'] );
		if ( ! $cat ) {
			throw new \InvalidArgumentException( 'Voce non valida.' );
		}
		return $this->insert_tx(
			array(
				'tx_date'          => $d['date'],
				'type'             => $d['type'],
				'amount_cents'     => (int) $d['cents'],
				'account_id'       => (int) $d['account_id'],
				'method'           => $d['method'],
				'category_id'      => (int) $cat['id'],
				'activity_id'      => ! empty( $d['activity_id'] ) ? (int) $d['activity_id'] : null,
				'person_id'        => ! empty( $d['person_id'] ) ? (int) $d['person_id'] : null,
				'description'      => mb_substr( trim( (string) ( $d['description'] ?? '' ) ), 0, 255 ),
				'competence_month' => ! empty( $d['month'] ) ? $d['month'] : null,
				'social_year'      => 'membership' === $cat['kind'] ? Settings::membership_year( (string) $d['date'] )->label() : null,
				'import_batch'     => ! empty( $d['batch'] ) ? (int) $d['batch'] : null,
				'document_ref'     => ! empty( $d['ref'] ) ? mb_substr( trim( (string) $d['ref'] ), 0, 80 ) : null,
			)
		);
	}

	/** Segna le righe di un giroconto come arrivate da un import (per poterlo annullare in blocco). */
	public function tag_transfer( string $transfer_id, int $batch ): void {
		$this->db()->update( Db::t( 'transactions' ), array( 'import_batch' => $batch ), array( 'transfer_id' => $transfer_id ) );
	}

	/** Sposta il saldo iniziale di un conto (serve a non cambiare il saldo attuale dopo l'import di movimenti storici). */
	public function shift_opening( int $account_id, int $delta ): void {
		if ( 0 === $delta ) {
			return;
		}
		$this->db()->query( $this->db()->prepare( 'UPDATE ' . Db::t( 'accounts' ) . ' SET opening_cents = opening_cents + %d WHERE id = %d', $delta, $account_id ) );
		Audit::log( 'account.opening_shifted', 'account', $account_id, array( 'delta_cents' => $delta ) );
	}

	/** Movimenti (non annullati, non giroconti) tra due date, per riconoscere i doppioni: chiave => quanti. */
	public function import_keys( string $from, string $to ): array {
		$rows = $this->db()->get_results(
			$this->db()->prepare(
				'SELECT tx_date, account_id, type, amount_cents, description, document_ref FROM ' . Db::t( 'transactions' )
				. " WHERE voided_at IS NULL AND type IN ('income','expense') AND tx_date BETWEEN %s AND %s",
				$from,
				$to
			),
			ARRAY_A
		) ?: array();
		$out = array();
		foreach ( $rows as $r ) {
			$k         = LedgerImport::key( $r['tx_date'], (string) (int) $r['account_id'], $r['type'], (int) $r['amount_cents'], (string) $r['description'], (string) $r['document_ref'] );
			$out[ $k ] = ( $out[ $k ] ?? 0 ) + 1;
		}
		// Giroconti: un'unica chiave per coppia (conto di uscita > conto di entrata)
		$t   = Db::t( 'transactions' );
		$tr  = $this->db()->get_results(
			$this->db()->prepare(
				"SELECT o.tx_date, o.account_id AS from_id, i.account_id AS to_id, o.amount_cents, o.description FROM $t o JOIN $t i ON i.transfer_id = o.transfer_id AND i.type = 'transfer_in' "
				. "WHERE o.type = 'transfer_out' AND o.voided_at IS NULL AND i.voided_at IS NULL AND o.tx_date BETWEEN %s AND %s",
				$from,
				$to
			),
			ARRAY_A
		) ?: array();
		foreach ( $tr as $r ) {
			$k         = LedgerImport::key( $r['tx_date'], (int) $r['from_id'] . '>' . (int) $r['to_id'], 'transfer', (int) $r['amount_cents'], (string) $r['description'], '' );
			$out[ $k ] = ( $out[ $k ] ?? 0 ) + 1;
		}
		return $out;
	}

	/** Ultime spese (non annullate) registrate da un utente: serve al tesoriere, che non vede il resto della prima nota. */
	public function expenses_by_user( int $user_id, int $limit = 15 ): array {
		$sql = 'SELECT t.*, c.name AS category_name, a.name AS account_name FROM ' . Db::t( 'transactions' ) . ' t '
			. 'JOIN ' . Db::t( 'categories' ) . ' c ON c.id = t.category_id JOIN ' . Db::t( 'accounts' ) . ' a ON a.id = t.account_id '
			. "WHERE t.voided_at IS NULL AND t.type = 'expense' AND t.created_by = %d ORDER BY t.tx_date DESC, t.id DESC LIMIT %d";
		return $this->db()->get_results( $this->db()->prepare( $sql, $user_id, max( 1, $limit ) ), ARRAY_A ) ?: array();
	}

	/** Movimenti (non annullati) di una persona. */
	public function rows_of_person( int $person_id ): array {
		$sql = 'SELECT t.*, a.name AS account_name, c.name AS category_name, act.name AS activity_name FROM ' . Db::t( 'transactions' ) . ' t '
			. 'JOIN ' . Db::t( 'accounts' ) . ' a ON a.id = t.account_id JOIN ' . Db::t( 'categories' ) . ' c ON c.id = t.category_id '
			. 'LEFT JOIN ' . Db::t( 'activities' ) . ' act ON act.id = t.activity_id '
			. 'WHERE t.voided_at IS NULL AND t.person_id = %d ORDER BY t.tx_date DESC, t.id DESC';
		return $this->db()->get_results( $this->db()->prepare( $sql, $person_id ), ARRAY_A ) ?: array();
	}
}
